(function () {
  const btn = document.getElementById('payBtn');
  if (!btn) return;

  async function postForm(url, formData) {
    const res = await fetch(url, {
      method: 'POST',
      body: formData,
      credentials: 'same-origin',
    });
    const data = await res.json().catch(() => null);
    if (!data) throw new Error('Unexpected server response');
    if (!res.ok || data.ok === false) {
      throw new Error(data.error || 'Request failed');
    }
    return data;
  }

  btn.addEventListener('click', async function () {
    btn.disabled = true;

    const bookingId = btn.dataset.bookingId;
    const csrf = btn.dataset.csrf;
    const keyId = btn.dataset.keyId;
    const createOrderUrl = btn.dataset.createOrderUrl;
    const verifyUrl = btn.dataset.verifyUrl;
    const successUrl = btn.dataset.successUrl;

    try {
      const form = new FormData();
      form.append('_csrf', csrf);
      form.append('booking_id', bookingId);

      const orderRes = await postForm(createOrderUrl, form);
      if (orderRes.alreadyPaid) {
        window.location.href = successUrl;
        return;
      }

      const order = orderRes.order;
      if (!order || !order.id) throw new Error('Missing order id');

      const options = {
        key: keyId,
        amount: order.amount,
        currency: order.currency,
        name: order.name,
        description: order.description,
        order_id: order.id,
        handler: async function (response) {
          try {
            const verifyForm = new FormData();
            verifyForm.append('_csrf', csrf);
            verifyForm.append('booking_id', bookingId);
            verifyForm.append('razorpay_order_id', response.razorpay_order_id);
            verifyForm.append('razorpay_payment_id', response.razorpay_payment_id);
            verifyForm.append('razorpay_signature', response.razorpay_signature);

            const verifyRes = await postForm(verifyUrl, verifyForm);
            window.location.href = verifyRes.redirect || successUrl;
          } catch (err) {
            alert(err.message || String(err));
            btn.disabled = false;
          }
        },
      };

      const rzp = new Razorpay(options);
      rzp.on('payment.failed', function (resp) {
        const msg = (resp && resp.error && (resp.error.description || resp.error.reason)) || 'Payment failed';
        alert(msg);
        btn.disabled = false;
      });
      rzp.open();
    } catch (err) {
      alert(err.message || String(err));
      btn.disabled = false;
    }
  });
})();
