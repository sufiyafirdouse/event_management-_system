<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/functions.php';

// Default landing: user-facing events list.
redirect('/user/view_events.php');

