<?php
declare(strict_types=1);

function render_certificate(array $cert): void
{
	?>
	<!doctype html>
	<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Certificate</title>
		<style>
			body { font-family: Arial, sans-serif; padding: 40px; }
			.box { border: 2px solid #333; padding: 40px; max-width: 900px; margin: 0 auto; }
			.title { font-size: 32px; font-weight: bold; text-align: center; margin-bottom: 16px; }
			.subtitle { text-align: center; margin-bottom: 32px; }
			.name { font-size: 28px; text-align: center; margin: 24px 0; font-weight: bold; }
			.meta { margin-top: 24px; display: flex; justify-content: space-between; gap: 16px; }
			.muted { color: #555; font-size: 13px; }
			@media print { .no-print { display: none; } }
		</style>
	</head>
	<body>
	<div class="box">
		<div class="title">Certificate of Participation</div>
		<div class="subtitle">This is to certify that</div>
		<div class="name"><?= htmlspecialchars((string)($cert['user_name'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?></div>
		<div class="subtitle">
			has participated in
			<strong><?= htmlspecialchars((string)($cert['event_title'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?></strong>
			on <strong><?= htmlspecialchars((string)($cert['event_start'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?></strong>.
		</div>

		<div class="meta">
			<div>
				<div class="muted">Certificate Code</div>
				<div><?= htmlspecialchars((string)($cert['certificate_code'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?></div>
			</div>
			<div style="text-align:right;">
				<div class="muted">Issued At</div>
				<div><?= htmlspecialchars((string)($cert['issued_at'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?></div>
			</div>
		</div>
	</div>

	<p class="no-print muted" style="text-align:center; margin-top:18px;">
		Tip: use your browser’s Print → Save as PDF to download.
	</p>
	</body>
	</html>
	<?php
}

