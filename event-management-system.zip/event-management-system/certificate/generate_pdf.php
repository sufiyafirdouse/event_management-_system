<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

// Certificate can be viewed by the owning user or an admin.
$code = trim((string)($_GET['code'] ?? ''));
if ($code === '') {
	http_response_code(400);
	exit('Missing certificate code');
}

$conn = db();
$stmt = $conn->prepare(
	"SELECT
		c.certificate_code,
		c.issued_at,
		u.name AS user_name,
		u.email AS user_email,
		e.title AS event_title,
		e.start_datetime AS event_start,
		b.user_id AS booking_user_id
	FROM certificates c
	INNER JOIN bookings b ON b.id = c.booking_id
	INNER JOIN users u ON u.id = b.user_id
	INNER JOIN events e ON e.id = b.event_id
	WHERE c.certificate_code = ?"
);
$stmt->bind_param('s', $code);
$stmt->execute();
$cert = $stmt->get_result()->fetch_assoc();

if (!$cert) {
	http_response_code(404);
	exit('Certificate not found');
}

if (!admin_id()) {
	require_user_login();
	if ((int)$cert['booking_user_id'] !== (int)user_id()) {
		http_response_code(403);
		exit('Forbidden');
	}
}

// For MVP: HTML certificate (print to PDF).
header('Content-Type: text/html; charset=utf-8');
require __DIR__ . '/certificate_template.php';

render_certificate($cert);

