	<footer class="footer">
		<div class="muted">&copy; <?= date('Y') ?> Event Management System</div>
	</footer>
</main>
</body>
</html>
