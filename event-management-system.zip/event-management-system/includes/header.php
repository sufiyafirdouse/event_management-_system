<?php
declare(strict_types=1);

require_once __DIR__ . '/session.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';

$scriptName = (string)($_SERVER['SCRIPT_NAME'] ?? '');
$isAdminArea = strpos($scriptName, '/admin/') !== false;
$isUserArea = strpos($scriptName, '/user/') !== false;

$flashError = get_flash('error');
$flashSuccess = get_flash('success');
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Event Management System</title>
	<link rel="stylesheet" href="<?= e(url('/assets/css/style.css')) ?>">
</head>
<body>
<header class="topbar">
	<div class="container">
		<div class="topbar-row">
			<a class="brand" href="<?= e(url('/index.php')) ?>">EMS</a>
			<nav class="nav">
				<?php if ($isAdminArea): ?>
					<?php if (admin_id()): ?>
						<a href="<?= e(url('/admin/dashboard.php')) ?>">Dashboard</a>
						<a href="<?= e(url('/admin/manage_events.php')) ?>">Events</a>
						<a href="<?= e(url('/admin/view_bookings.php')) ?>">Bookings</a>
						<a href="<?= e(url('/admin/mark_attendance.php')) ?>">Attendance</a>
						<a href="<?= e(url('/admin/logout.php')) ?>">Logout</a>
					<?php else: ?>
						<a href="<?= e(url('/admin/login.php')) ?>">Admin Login</a>
					<?php endif; ?>
				<?php elseif ($isUserArea): ?>
					<a href="<?= e(url('/user/view_events.php')) ?>">Events</a>
					<?php if (user_id()): ?>
						<a href="<?= e(url('/user/dashboard.php')) ?>">Dashboard</a>
						<a href="<?= e(url('/user/my_bookings.php')) ?>">My Bookings</a>
						<a href="<?= e(url('/user/download_certificate.php')) ?>">Certificates</a>
						<a href="<?= e(url('/user/logout.php')) ?>">Logout</a>
					<?php else: ?>
						<a href="<?= e(url('/user/login.php')) ?>">Login</a>
						<a href="<?= e(url('/user/register.php')) ?>">Register</a>
					<?php endif; ?>
				<?php else: ?>
					<a href="<?= e(url('/user/view_events.php')) ?>">Events</a>
					<a href="<?= e(url('/user/login.php')) ?>">User Login</a>
					<a href="<?= e(url('/admin/login.php')) ?>">Admin</a>
				<?php endif; ?>
			</nav>
		</div>
	</div>
</header>

<main class="container">
	<?php if ($flashError): ?>
		<div class="alert alert-error"><?= e($flashError) ?></div>
	<?php endif; ?>
	<?php if ($flashSuccess): ?>
		<div class="alert alert-success"><?= e($flashSuccess) ?></div>
	<?php endif; ?>
