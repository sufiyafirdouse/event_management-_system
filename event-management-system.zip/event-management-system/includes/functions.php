<?php
declare(strict_types=1);

require_once __DIR__ . '/session.php';
require_once __DIR__ . '/db.php';

function e(?string $value): string
{
	return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function redirect(string $path): never
{
	header('Location: ' . url($path));
	exit;
}

function set_flash(string $key, string $message): void
{
	$_SESSION['_flash'][$key] = $message;
}

function get_flash(string $key): ?string
{
	if (!isset($_SESSION['_flash'][$key])) {
		return null;
	}
	$msg = (string)$_SESSION['_flash'][$key];
	unset($_SESSION['_flash'][$key]);
	return $msg;
}

function csrf_token(): string
{
	if (empty($_SESSION['_csrf'])) {
		$_SESSION['_csrf'] = bin2hex(random_bytes(32));
	}
	return (string)$_SESSION['_csrf'];
}

function csrf_verify(?string $token): bool
{
	return is_string($token) && isset($_SESSION['_csrf']) && hash_equals((string)$_SESSION['_csrf'], $token);
}

function app_root_url(): string
{
	static $root = null;
	if (is_string($root)) {
		return $root;
	}

	$env = getenv('APP_ROOT_URL');
	if (is_string($env) && $env !== '') {
		$root = rtrim($env, '/');
		return $root;
	}

	$script = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
	foreach (['/admin/', '/user/', '/attendance/', '/certificate/', '/payment/'] as $marker) {
		$pos = stripos($script, $marker);
		if ($pos !== false) {
			$root = rtrim(substr($script, 0, $pos), '/');
			return $root;
		}
	}

	$root = rtrim(str_replace('\\', '/', dirname($script)), '/');
	return $root;
}

function url(string $path = ''): string
{
	$base = app_root_url();
	if ($path === '' || $path === '/') {
		return $base . '/';
	}
	if ($path[0] !== '/') {
		$path = '/' . $path;
	}
	return $base . $path;
}

function require_post_and_csrf(): void
{
	if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
		http_response_code(405);
		exit('Method Not Allowed');
	}
	if (!csrf_verify($_POST['_csrf'] ?? null)) {
		http_response_code(400);
		exit('Invalid CSRF token');
	}
}

function ensure_default_admin_exists(): void
{
	// Creates a default admin only when admins table is empty.
	// Default credentials: admin / admin123 (change ASAP)
	$conn = db();
	$count = (int)$conn->query('SELECT COUNT(*) AS c FROM admins')->fetch_assoc()['c'];
	if ($count > 0) {
		return;
	}

	$username = 'admin';
	$passwordHash = password_hash('admin123', PASSWORD_DEFAULT);
	$stmt = $conn->prepare('INSERT INTO admins (username, password_hash) VALUES (?, ?)');
	$stmt->bind_param('ss', $username, $passwordHash);
	$stmt->execute();
}

function razorpay_key_id(): string
{
	$id = getenv('RAZORPAY_KEY_ID');
	return (is_string($id) && $id !== '') ? $id : '';
}

function razorpay_key_secret(): string
{
	$secret = getenv('RAZORPAY_KEY_SECRET');
	return (is_string($secret) && $secret !== '') ? $secret : '';
}

function razorpay_is_configured(): bool
{
	return razorpay_key_id() !== '' && razorpay_key_secret() !== '';
}
