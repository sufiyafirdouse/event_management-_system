<?php
declare(strict_types=1);

// Basic session hardening for typical local dev.
$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');

if (session_status() === PHP_SESSION_NONE) {
	session_set_cookie_params([
		'lifetime' => 0,
		'path' => '/',
		'httponly' => true,
		'samesite' => 'Lax',
		'secure' => $isHttps,
	]);
	session_start();
}
