<?php
declare(strict_types=1);

require_once __DIR__ . '/session.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/db.php';

function admin_id(): ?int
{
	return isset($_SESSION['admin_id']) ? (int)$_SESSION['admin_id'] : null;
}

function user_id(): ?int
{
	return isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null;
}

function require_admin_login(): void
{
	if (!admin_id()) {
		set_flash('error', 'Please login as admin.');
		redirect('/admin/login.php');
	}
}

function require_user_login(): void
{
	if (!user_id()) {
		set_flash('error', 'Please login.');
		redirect('/user/login.php');
	}
}

function logout_admin(): void
{
	unset($_SESSION['admin_id']);
}

function logout_user(): void
{
	unset($_SESSION['user_id']);
}
