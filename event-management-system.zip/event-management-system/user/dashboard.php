<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

require_user_login();

$conn = db();
$uid = (int)user_id();

$stmt = $conn->prepare(
	"SELECT
		b.booking_ref,
		b.status,
		b.payment_status,
		b.amount,
		b.created_at,
		e.title AS event_title,
		e.start_datetime AS event_start
	FROM bookings b
	INNER JOIN events e ON e.id = b.event_id
	WHERE b.user_id = ?
	ORDER BY b.created_at DESC
	LIMIT 10"
);
$stmt->bind_param('i', $uid);
$stmt->execute();
$recent = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

require_once __DIR__ . '/../includes/header.php';
?>

<h1>User Dashboard</h1>

<div class="page-row">
	<a class="btn" href="<?= e(url('/user/view_events.php')) ?>">Browse events</a>
	<a class="btn btn-secondary" href="<?= e(url('/user/my_bookings.php')) ?>">My bookings</a>
	<a class="btn btn-secondary" href="<?= e(url('/user/download_certificate.php')) ?>">Certificates</a>
</div>

<h2 style="margin-top:16px;">Recent bookings</h2>
<div class="card">
	<table class="table">
		<thead>
		<tr>
			<th>Ref</th>
			<th>Event</th>
			<th>Start</th>
			<th>Status</th>
			<th>Payment</th>
		</tr>
		</thead>
		<tbody>
		<?php if (!$recent): ?>
			<tr><td colspan="5" class="muted">No bookings yet.</td></tr>
		<?php else: ?>
			<?php foreach ($recent as $r): ?>
				<tr>
					<td><?= e($r['booking_ref']) ?></td>
					<td><?= e($r['event_title']) ?></td>
					<td><?= e($r['event_start']) ?></td>
					<td><?= e($r['status']) ?></td>
					<td><?= e($r['payment_status']) ?></td>
				</tr>
			<?php endforeach; ?>
		<?php endif; ?>
		</tbody>
	</table>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

