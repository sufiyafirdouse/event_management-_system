<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

require_user_login();

$conn = db();
$uid = (int)user_id();

$stmt = $conn->prepare(
	"SELECT
		b.id,
		b.booking_ref,
		b.status,
		b.payment_status,
		b.amount,
		b.created_at,
		e.title AS event_title,
		e.start_datetime AS event_start
	FROM bookings b
	INNER JOIN events e ON e.id = b.event_id
	WHERE b.user_id = ?
	ORDER BY b.created_at DESC"
);
$stmt->bind_param('i', $uid);
$stmt->execute();
$rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

require_once __DIR__ . '/../includes/header.php';
?>

<h1>My Bookings</h1>

<div class="card">
	<table class="table">
		<thead>
		<tr>
			<th>Ref</th>
			<th>Event</th>
			<th>Start</th>
			<th>Status</th>
			<th>Payment</th>
			<th>Amount</th>
			<th></th>
		</tr>
		</thead>
		<tbody>
		<?php if (!$rows): ?>
			<tr><td colspan="7" class="muted">No bookings yet.</td></tr>
		<?php else: ?>
			<?php foreach ($rows as $r): ?>
				<tr>
					<td><?= e($r['booking_ref']) ?></td>
					<td><?= e($r['event_title']) ?></td>
					<td><?= e($r['event_start']) ?></td>
					<td><?= e($r['status']) ?></td>
					<td><?= e($r['payment_status']) ?></td>
					<td><?= e(number_format((float)$r['amount'], 2)) ?></td>
					<td>
						<?php if ($r['payment_status'] === 'UNPAID'): ?>
							<a class="btn" href="<?= e(url('/user/payment.php?booking_id=' . (int)$r['id'])) ?>">Pay</a>
						<?php else: ?>
							<span class="muted">—</span>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
		<?php endif; ?>
		</tbody>
	</table>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

