<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

if (user_id()) {
	redirect('/user/dashboard.php');
}

$error = null;
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
	if (!csrf_verify($_POST['_csrf'] ?? null)) {
		$error = 'Invalid CSRF token.';
	} else {
		$email = strtolower(trim((string)($_POST['email'] ?? '')));
		$password = (string)($_POST['password'] ?? '');

		if ($email === '' || $password === '') {
			$error = 'Email and password are required.';
		} else {
			$conn = db();
			$stmt = $conn->prepare('SELECT id, password_hash FROM users WHERE email = ?');
			$stmt->bind_param('s', $email);
			$stmt->execute();
			$row = $stmt->get_result()->fetch_assoc();
			if ($row && password_verify($password, (string)$row['password_hash'])) {
				$_SESSION['user_id'] = (int)$row['id'];
				set_flash('success', 'Logged in.');
				redirect('/user/dashboard.php');
			}
			$error = 'Invalid credentials.';
		}
	}
}

require_once __DIR__ . '/../includes/header.php';
?>

<h1>User Login</h1>

<?php if ($error): ?>
	<div class="alert alert-error"><?= e($error) ?></div>
<?php endif; ?>

<div class="card">
	<form method="post" action="">
		<input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
		<div class="field">
			<label>Email</label>
			<input class="input" type="email" name="email" autocomplete="username" required>
		</div>
		<div class="field">
			<label>Password</label>
			<input class="input" type="password" name="password" autocomplete="current-password" required>
		</div>
		<button class="btn" type="submit">Login</button>
	</form>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

