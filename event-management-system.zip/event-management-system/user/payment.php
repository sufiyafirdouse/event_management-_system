<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../payment/razorpay_config.php';

require_user_login();

$bookingId = (int)($_GET['booking_id'] ?? 0);
if ($bookingId <= 0) {
	http_response_code(400);
	exit('Missing booking id');
}

$conn = db();
$uid = (int)user_id();

$stmt = $conn->prepare(
	"SELECT
		b.id,
		b.booking_ref,
		b.status,
		b.payment_status,
		b.amount,
		e.title AS event_title
	FROM bookings b
	INNER JOIN events e ON e.id = b.event_id
	WHERE b.id = ? AND b.user_id = ?"
);
$stmt->bind_param('ii', $bookingId, $uid);
$stmt->execute();
$booking = $stmt->get_result()->fetch_assoc();

if (!$booking) {
	http_response_code(404);
	exit('Booking not found');
}

require_once __DIR__ . '/../includes/header.php';
?>

<h1>Payment</h1>

<div class="card">
	<p><strong>Event:</strong> <?= e($booking['event_title']) ?></p>
	<p><strong>Booking Ref:</strong> <?= e($booking['booking_ref']) ?></p>
	<p><strong>Amount:</strong> <?= e(number_format((float)$booking['amount'], 2)) ?></p>
	<p><strong>Status:</strong> <?= e($booking['payment_status']) ?></p>

	<?php if ($booking['payment_status'] === 'PAID'): ?>
		<div class="alert alert-success">Payment already completed.</div>
		<a class="btn" href="<?= e(url('/user/my_bookings.php')) ?>">Back to bookings</a>
	<?php elseif ((float)$booking['amount'] <= 0): ?>
		<div class="alert alert-success">This event is free. No payment required.</div>
		<a class="btn" href="<?= e(url('/user/my_bookings.php')) ?>">Back to bookings</a>
	<?php elseif (!razorpay_is_configured()): ?>
		<div class="alert alert-error">
			Razorpay is not configured. Set `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET` (env vars) or edit the placeholders in `payment/razorpay_config.php`.
		</div>
		<a class="btn" href="<?= e(url('/user/my_bookings.php')) ?>">Back</a>
	<?php else: ?>
		<button
			id="payBtn"
			class="btn"
			data-booking-id="<?= e((string)$bookingId) ?>"
			data-csrf="<?= e(csrf_token()) ?>"
			data-key-id="<?= e(razorpay_key_id()) ?>"
			data-create-order-url="<?= e(url('/payment/create_order.php')) ?>"
			data-verify-url="<?= e(url('/payment/verify_payment.php')) ?>"
			data-success-url="<?= e(url('/user/my_bookings.php')) ?>"
			data-event-title="<?= e($booking['event_title']) ?>"
		>Pay with Razorpay</button>

		<p class="muted" style="margin-top:12px;">You’ll see the Razorpay checkout popup.</p>

		<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
		<script src="<?= e(url('/assets/js/payment.js')) ?>"></script>
	<?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

