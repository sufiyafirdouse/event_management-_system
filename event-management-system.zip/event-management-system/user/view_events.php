<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

$conn = db();
$sql = "
	SELECT
		e.*,
		(SELECT COUNT(*) FROM bookings b WHERE b.event_id = e.id AND b.status IN ('PENDING','CONFIRMED')) AS booked_count
	FROM events e
	WHERE e.is_active = 1
	ORDER BY e.start_datetime ASC
";
$events = $conn->query($sql)->fetch_all(MYSQLI_ASSOC);

require_once __DIR__ . '/../includes/header.php';
?>

<h1>Events</h1>

<div class="card">
	<table class="table">
		<thead>
		<tr>
			<th>Title</th>
			<th>Start</th>
			<th>Location</th>
			<th>Price</th>
			<th>Seats</th>
			<th></th>
		</tr>
		</thead>
		<tbody>
		<?php if (!$events): ?>
			<tr><td colspan="6" class="muted">No active events.</td></tr>
		<?php else: ?>
			<?php foreach ($events as $ev): ?>
				<?php
				$capacity = $ev['capacity'] === null ? null : (int)$ev['capacity'];
				$booked = (int)$ev['booked_count'];
				$isFull = ($capacity !== null) && ($booked >= $capacity);
				?>
				<tr>
					<td>
						<div><strong><?= e($ev['title']) ?></strong></div>
						<?php if (!empty($ev['description'])): ?>
							<?php
							$desc = (string)$ev['description'];
							if (function_exists('mb_strimwidth')) {
								$descShort = mb_strimwidth($desc, 0, 120, '…');
							} else {
								$descShort = strlen($desc) > 120 ? (substr($desc, 0, 117) . '...') : $desc;
							}
							?>
							<div class="muted"><?= e($descShort) ?></div>
						<?php endif; ?>
					</td>
					<td><?= e($ev['start_datetime']) ?></td>
					<td><?= e($ev['location']) ?></td>
					<td><?= e(number_format((float)$ev['price'], 2)) ?></td>
					<td>
						<?php if ($capacity === null): ?>
							Unlimited
						<?php else: ?>
							<?= e((string)max(0, $capacity - $booked)) ?> left
						<?php endif; ?>
					</td>
					<td>
						<?php if (!user_id()): ?>
							<a class="btn" href="<?= e(url('/user/login.php')) ?>">Login to book</a>
						<?php elseif ($isFull): ?>
							<span class="muted">Full</span>
						<?php else: ?>
							<form method="post" action="<?= e(url('/user/book_event.php')) ?>" style="display:inline;">
								<input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
								<input type="hidden" name="event_id" value="<?= e((string)$ev['id']) ?>">
								<button class="btn" type="submit">Book</button>
							</form>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
		<?php endif; ?>
		</tbody>
	</table>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

