<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

if (user_id()) {
	redirect('/user/dashboard.php');
}

$error = null;
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
	if (!csrf_verify($_POST['_csrf'] ?? null)) {
		$error = 'Invalid CSRF token.';
	} else {
		$name = trim((string)($_POST['name'] ?? ''));
		$email = strtolower(trim((string)($_POST['email'] ?? '')));
		$phone = trim((string)($_POST['phone'] ?? ''));
		$password = (string)($_POST['password'] ?? '');

		if ($name === '' || $email === '' || $password === '') {
			$error = 'Name, email and password are required.';
		} else {
			$conn = db();
			$stmt = $conn->prepare('SELECT id FROM users WHERE email = ?');
			$stmt->bind_param('s', $email);
			$stmt->execute();
			if ($stmt->get_result()->fetch_assoc()) {
				$error = 'Email is already registered.';
			} else {
				$hash = password_hash($password, PASSWORD_DEFAULT);
				$stmt = $conn->prepare('INSERT INTO users (name, email, phone, password_hash) VALUES (?,?,?,?)');
				$stmt->bind_param('ssss', $name, $email, $phone, $hash);
				$stmt->execute();
				$_SESSION['user_id'] = (int)$conn->insert_id;
				set_flash('success', 'Account created.');
				redirect('/user/dashboard.php');
			}
		}
	}
}

require_once __DIR__ . '/../includes/header.php';
?>

<h1>Create Account</h1>

<?php if ($error): ?>
	<div class="alert alert-error"><?= e($error) ?></div>
<?php endif; ?>

<div class="card">
	<form method="post" action="">
		<input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
		<div class="field">
			<label>Name</label>
			<input class="input" type="text" name="name" required>
		</div>
		<div class="field">
			<label>Email</label>
			<input class="input" type="email" name="email" required>
		</div>
		<div class="field">
			<label>Phone</label>
			<input class="input" type="text" name="phone">
		</div>
		<div class="field">
			<label>Password</label>
			<input class="input" type="password" name="password" required>
		</div>
		<button class="btn" type="submit">Register</button>
	</form>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

