<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

require_user_login();

$conn = db();
$uid = (int)user_id();

$stmt = $conn->prepare(
	"SELECT
		c.certificate_code,
		c.issued_at,
		e.title AS event_title,
		e.start_datetime AS event_start
	FROM certificates c
	INNER JOIN bookings b ON b.id = c.booking_id
	INNER JOIN events e ON e.id = b.event_id
	WHERE b.user_id = ?
	ORDER BY c.issued_at DESC"
);
$stmt->bind_param('i', $uid);
$stmt->execute();
$rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

require_once __DIR__ . '/../includes/header.php';
?>

<h1>My Certificates</h1>

<div class="card">
	<table class="table">
		<thead>
		<tr>
			<th>Certificate Code</th>
			<th>Event</th>
			<th>Event Start</th>
			<th>Issued</th>
			<th></th>
		</tr>
		</thead>
		<tbody>
		<?php if (!$rows): ?>
			<tr><td colspan="5" class="muted">No certificates available yet.</td></tr>
		<?php else: ?>
			<?php foreach ($rows as $r): ?>
				<tr>
					<td><?= e($r['certificate_code']) ?></td>
					<td><?= e($r['event_title']) ?></td>
					<td><?= e($r['event_start']) ?></td>
					<td><?= e($r['issued_at']) ?></td>
					<td>
						<a class="btn" href="<?= e(url('/certificate/generate_pdf.php?code=' . urlencode((string)$r['certificate_code']))) ?>">View</a>
					</td>
				</tr>
			<?php endforeach; ?>
		<?php endif; ?>
		</tbody>
	</table>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

