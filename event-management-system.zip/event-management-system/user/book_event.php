<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

require_user_login();
require_post_and_csrf();

$eventId = (int)($_POST['event_id'] ?? 0);
if ($eventId <= 0) {
	http_response_code(400);
	exit('Missing event id');
}

$conn = db();
$uid = (int)user_id();

// Load event and ensure active
$stmt = $conn->prepare('SELECT id, capacity, price, is_active FROM events WHERE id = ?');
$stmt->bind_param('i', $eventId);
$stmt->execute();
$event = $stmt->get_result()->fetch_assoc();

if (!$event || (int)$event['is_active'] !== 1) {
	set_flash('error', 'Event not available.');
	redirect('/user/view_events.php');
}

// Capacity check
$capacity = $event['capacity'] === null ? null : (int)$event['capacity'];
if ($capacity !== null) {
	$stmt = $conn->prepare("SELECT COUNT(*) AS c FROM bookings WHERE event_id = ? AND status IN ('PENDING','CONFIRMED')");
	$stmt->bind_param('i', $eventId);
	$stmt->execute();
	$booked = (int)$stmt->get_result()->fetch_assoc()['c'];
	if ($booked >= $capacity) {
		set_flash('error', 'Event is full.');
		redirect('/user/view_events.php');
	}
}

// Prevent duplicate booking
$stmt = $conn->prepare('SELECT id FROM bookings WHERE user_id = ? AND event_id = ?');
$stmt->bind_param('ii', $uid, $eventId);
$stmt->execute();
if ($stmt->get_result()->fetch_assoc()) {
	set_flash('error', 'You already booked this event.');
	redirect('/user/my_bookings.php');
}

$amount = (float)$event['price'];
$status = $amount > 0 ? 'PENDING' : 'CONFIRMED';
$paymentStatus = $amount > 0 ? 'UNPAID' : 'PAID';
$bookingRef = 'BKG-' . strtoupper(bin2hex(random_bytes(4)));

$stmt = $conn->prepare('INSERT INTO bookings (booking_ref, user_id, event_id, status, payment_status, amount) VALUES (?,?,?,?,?,?)');
$stmt->bind_param('siissd', $bookingRef, $uid, $eventId, $status, $paymentStatus, $amount);
$stmt->execute();
$bookingId = (int)$conn->insert_id;

if ($amount > 0) {
	redirect('/user/payment.php?booking_id=' . $bookingId);
}

set_flash('success', 'Booking confirmed.');
redirect('/user/my_bookings.php');

