<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/razorpay_config.php';

header('Content-Type: application/json; charset=utf-8');

require_user_login();
require_post_and_csrf();

if (!razorpay_is_configured()) {
	http_response_code(400);
	echo json_encode(['ok' => false, 'error' => 'Razorpay not configured']);
	exit;
}

$bookingId = (int)($_POST['booking_id'] ?? 0);
if ($bookingId <= 0) {
	http_response_code(400);
	echo json_encode(['ok' => false, 'error' => 'Missing booking_id']);
	exit;
}

$conn = db();
$uid = (int)user_id();

$stmt = $conn->prepare(
	"SELECT b.id, b.booking_ref, b.amount, b.payment_status, e.title AS event_title
	 FROM bookings b
	 INNER JOIN events e ON e.id = b.event_id
	 WHERE b.id = ? AND b.user_id = ?"
);
$stmt->bind_param('ii', $bookingId, $uid);
$stmt->execute();
$booking = $stmt->get_result()->fetch_assoc();

if (!$booking) {
	http_response_code(404);
	echo json_encode(['ok' => false, 'error' => 'Booking not found']);
	exit;
}

if ($booking['payment_status'] === 'PAID') {
	echo json_encode(['ok' => true, 'alreadyPaid' => true]);
	exit;
}

$amount = (float)$booking['amount'];
if ($amount <= 0) {
	http_response_code(400);
	echo json_encode(['ok' => false, 'error' => 'Invalid amount']);
	exit;
}

$payload = [
	'amount' => (int)round($amount * 100),
	'currency' => 'INR',
	'receipt' => (string)$booking['booking_ref'],
	'notes' => [
		'booking_id' => (string)$bookingId,
	],
];

$ch = curl_init('https://api.razorpay.com/v1/orders');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
curl_setopt($ch, CURLOPT_USERPWD, razorpay_key_id() . ':' . razorpay_key_secret());
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));

$resp = curl_exec($ch);
$http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
$err = curl_error($ch);
curl_close($ch);

if ($resp === false || $http < 200 || $http >= 300) {
	http_response_code(502);
	echo json_encode(['ok' => false, 'error' => 'Razorpay order creation failed', 'details' => $err ?: $resp]);
	exit;
}

$data = json_decode((string)$resp, true);
$orderId = (string)($data['id'] ?? '');
if ($orderId === '') {
	http_response_code(502);
	echo json_encode(['ok' => false, 'error' => 'Unexpected Razorpay response']);
	exit;
}

$stmt = $conn->prepare('UPDATE bookings SET razorpay_order_id = ? WHERE id = ?');
$stmt->bind_param('si', $orderId, $bookingId);
$stmt->execute();

echo json_encode([
	'ok' => true,
	'order' => [
		'id' => $orderId,
		'amount' => $payload['amount'],
		'currency' => 'INR',
		'name' => 'Event Management System',
		'description' => (string)$booking['event_title'],
	],
]);

