<?php
declare(strict_types=1);

// Configure via env vars (recommended):
//   RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET
// Helpers are defined in includes/functions.php.

