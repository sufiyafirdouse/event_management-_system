<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/razorpay_config.php';

header('Content-Type: application/json; charset=utf-8');

require_user_login();
require_post_and_csrf();

if (!razorpay_is_configured()) {
	http_response_code(400);
	echo json_encode(['ok' => false, 'error' => 'Razorpay not configured']);
	exit;
}

$bookingId = (int)($_POST['booking_id'] ?? 0);
$orderId = trim((string)($_POST['razorpay_order_id'] ?? ''));
$paymentId = trim((string)($_POST['razorpay_payment_id'] ?? ''));
$signature = trim((string)($_POST['razorpay_signature'] ?? ''));

if ($bookingId <= 0 || $orderId === '' || $paymentId === '' || $signature === '') {
	http_response_code(400);
	echo json_encode(['ok' => false, 'error' => 'Missing payment fields']);
	exit;
}

$expected = hash_hmac('sha256', $orderId . '|' . $paymentId, razorpay_key_secret());
if (!hash_equals($expected, $signature)) {
	http_response_code(400);
	echo json_encode(['ok' => false, 'error' => 'Invalid signature']);
	exit;
}

$conn = db();
$uid = (int)user_id();

$stmt = $conn->prepare('SELECT id, payment_status FROM bookings WHERE id = ? AND user_id = ?');
$stmt->bind_param('ii', $bookingId, $uid);
$stmt->execute();
$booking = $stmt->get_result()->fetch_assoc();
if (!$booking) {
	http_response_code(404);
	echo json_encode(['ok' => false, 'error' => 'Booking not found']);
	exit;
}

if ($booking['payment_status'] !== 'PAID') {
	$stmt = $conn->prepare("UPDATE bookings SET payment_status='PAID', status='CONFIRMED', razorpay_order_id=?, razorpay_payment_id=?, razorpay_signature=? WHERE id=?");
	$stmt->bind_param('sssi', $orderId, $paymentId, $signature, $bookingId);
	$stmt->execute();
}

echo json_encode(['ok' => true, 'redirect' => url('/user/my_bookings.php')]);

