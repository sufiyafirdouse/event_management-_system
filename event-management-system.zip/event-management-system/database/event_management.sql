-- Event Management System (MVP)
-- MySQL/MariaDB schema

SET NAMES utf8mb4;
SET time_zone = '+00:00';

CREATE TABLE IF NOT EXISTS admins (
	id INT UNSIGNED NOT NULL AUTO_INCREMENT,
	username VARCHAR(100) NOT NULL,
	password_hash VARCHAR(255) NOT NULL,
	created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY (id),
	UNIQUE KEY uq_admins_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS users (
	id INT UNSIGNED NOT NULL AUTO_INCREMENT,
	name VARCHAR(150) NOT NULL,
	email VARCHAR(190) NOT NULL,
	phone VARCHAR(30) NULL,
	password_hash VARCHAR(255) NOT NULL,
	created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY (id),
	UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS events (
	id INT UNSIGNED NOT NULL AUTO_INCREMENT,
	title VARCHAR(200) NOT NULL,
	description TEXT NULL,
	location VARCHAR(200) NULL,
	start_datetime DATETIME NOT NULL,
	end_datetime DATETIME NULL,
	capacity INT UNSIGNED NULL,
	price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
	is_active TINYINT(1) NOT NULL DEFAULT 1,
	created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
	PRIMARY KEY (id),
	KEY idx_events_start (start_datetime),
	KEY idx_events_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bookings (
	id INT UNSIGNED NOT NULL AUTO_INCREMENT,
	booking_ref VARCHAR(50) NOT NULL,
	user_id INT UNSIGNED NOT NULL,
	event_id INT UNSIGNED NOT NULL,
	status ENUM('PENDING','CONFIRMED','CANCELLED') NOT NULL DEFAULT 'PENDING',
	payment_status ENUM('UNPAID','PAID','REFUNDED') NOT NULL DEFAULT 'UNPAID',
	amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
	razorpay_order_id VARCHAR(100) NULL,
	razorpay_payment_id VARCHAR(100) NULL,
	razorpay_signature VARCHAR(255) NULL,
	created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
	PRIMARY KEY (id),
	UNIQUE KEY uq_bookings_ref (booking_ref),
	UNIQUE KEY uq_bookings_user_event (user_id, event_id),
	KEY idx_bookings_event (event_id),
	KEY idx_bookings_user (user_id),
	KEY idx_bookings_status (status),
	CONSTRAINT fk_bookings_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
	CONSTRAINT fk_bookings_event FOREIGN KEY (event_id) REFERENCES events (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS attendance (
	id INT UNSIGNED NOT NULL AUTO_INCREMENT,
	booking_id INT UNSIGNED NOT NULL,
	attended TINYINT(1) NOT NULL DEFAULT 0,
	marked_by_admin_id INT UNSIGNED NULL,
	marked_at TIMESTAMP NULL DEFAULT NULL,
	PRIMARY KEY (id),
	UNIQUE KEY uq_attendance_booking (booking_id),
	KEY idx_attendance_attended (attended),
	CONSTRAINT fk_attendance_booking FOREIGN KEY (booking_id) REFERENCES bookings (id) ON DELETE CASCADE,
	CONSTRAINT fk_attendance_admin FOREIGN KEY (marked_by_admin_id) REFERENCES admins (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS certificates (
	id INT UNSIGNED NOT NULL AUTO_INCREMENT,
	booking_id INT UNSIGNED NOT NULL,
	certificate_code VARCHAR(80) NOT NULL,
	issued_by_admin_id INT UNSIGNED NULL,
	issued_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY (id),
	UNIQUE KEY uq_certificates_booking (booking_id),
	UNIQUE KEY uq_certificates_code (certificate_code),
	CONSTRAINT fk_certificates_booking FOREIGN KEY (booking_id) REFERENCES bookings (id) ON DELETE CASCADE,
	CONSTRAINT fk_certificates_admin FOREIGN KEY (issued_by_admin_id) REFERENCES admins (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
