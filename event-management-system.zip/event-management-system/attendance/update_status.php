<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

require_admin_login();
require_post_and_csrf();

$bookingId = (int)($_POST['booking_id'] ?? 0);
$eventId = (int)($_POST['event_id'] ?? 0);
$attended = (int)($_POST['attended'] ?? 0) === 1 ? 1 : 0;

if ($bookingId <= 0) {
	http_response_code(400);
	exit('Missing booking id');
}

$conn = db();

// Upsert attendance
$stmt = $conn->prepare('SELECT id FROM attendance WHERE booking_id = ?');
$stmt->bind_param('i', $bookingId);
$stmt->execute();
$existing = $stmt->get_result()->fetch_assoc();

$adminId = admin_id();
$now = date('Y-m-d H:i:s');

if ($existing) {
	$attId = (int)$existing['id'];
	$stmt = $conn->prepare('UPDATE attendance SET attended=?, marked_by_admin_id=?, marked_at=? WHERE id=?');
	$stmt->bind_param('iisi', $attended, $adminId, $now, $attId);
	$stmt->execute();
} else {
	$stmt = $conn->prepare('INSERT INTO attendance (booking_id, attended, marked_by_admin_id, marked_at) VALUES (?,?,?,?)');
	$stmt->bind_param('iiis', $bookingId, $attended, $adminId, $now);
	$stmt->execute();
}

set_flash('success', 'Attendance updated.');
redirect('/admin/mark_attendance.php?event_id=' . $eventId);

